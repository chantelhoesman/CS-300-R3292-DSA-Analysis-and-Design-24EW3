#include <iostream>
#include <fstream>
#include <string>
#include <algorithm>
#include <vector>
#include <sstream>

using namespace std;

//Create struct of Course 
struct Course {
    string courseId;
    string courseTitle;
    vector<string> prerequisites;
};

// Create a function to load data  from file
static void loadData(vector<Course>& courseData) {

    ifstream file;
    //Open the file 
    file.open("ABCU Advising Program.csv");
    //If file is not open print file is not open
    if (!file.is_open()) {
        cout << "File is not open. " << endl;
    }
    //If file is open getline 
    if (file.is_open()) {
        string line;
        //getline(file, line);
        while (getline(file, line)) {
            Course newCourse;
            stringstream ss(line);
            getline(ss, newCourse.courseId);
            getline(ss, newCourse.courseTitle);

            string prerequisite;
            //Nested while to get prerequisites
            while (getline(ss, prerequisite)) {
                newCourse.prerequisites.push_back(prerequisite);
            }
            courseData.push_back(newCourse);
        }
        file.close(); //Close the file
    }
}
   

//Create function to print the sorted course list
static void printCourseList(const vector<Course>& courseData) {
    //Intanstiate the vector sortedData 
    vector<Course> sortedData = courseData;
    sort(sortedData.begin(), sortedData.end(),
        [](const Course& a, const Course& b) {
            return a.courseId < b.courseId;
        });

    // Once sorted print the sorted list
    for (const auto& course : sortedData) {
        cout << course.courseId << ", " << course.courseTitle << endl;
    }
}

// Function to print course information
static void printCourseInfo(const vector<Course>& courseData) {
    string courseCourseId;
    cout << "Enter the course courseId: ";
    cin >> courseCourseId;

    // Search for the course in courseData
    auto it = find_if(courseData.begin(), courseData.end(),
        [courseCourseId](const Course& course) {
            return course.courseId == courseCourseId;
        });

    if (it != courseData.end()) {
        // Course found, print information
        cout << it->courseId << ", " << it->courseTitle << endl;
        cout << "Prerequisites: ";
        for (const auto& prereq : it->prerequisites) {
            cout << prereq << ", ";
        }
        cout << endl;
    }
    else {
        cout << "Course not found." << endl;
    }
}

int main() {
    vector<Course> courseData;  // Initilize the vector to hold the data
    
  //Create menu for interface
    cout << "Welcome to the course Planner\n";

    while (true) {
        int choice;
        cout << "\t 1. Load Data Structure\n";
        cout << "\t 2. Print Course List\n";
        cout << "\t 3. Print Course\n";
        cout << "\t 9. Exit\n";
        cout << "What would you like to do? ";
        cin >> choice;
        cout << "\n";

        switch (choice) {
        case 1:
            loadData(courseData);
            break;
        case 2:
            printCourseList(courseData);
            break;
        case 3:
            printCourseInfo(courseData);
            break;
        case 9:
            cout << "Exiting the program.\n";
            return 0;
        default:
            cout << choice << " is not a valid option\n";
            break;
        }
    }

    return 0;
}
